package com.cap.parallelBean;

public class TransBean {
private long  Transid;
private long accountnumber;
private long amount;
private long amountrecieved;
private String transtype;
private String Transdate;

public TransBean(long transid, long accountnumber, long amount, long amountrecieved, String transtype, String transdate) {
	super();
	Transid = transid;
	this.accountnumber = accountnumber;
	this.amount = amount;
	this.amountrecieved = amountrecieved;
	this.transtype =  transtype;
	this.Transdate = transdate;
}


public TransBean() {
	// TODO Auto-generated constructor stub
}


@Override
public String toString() {
	return "\n Transid=" + Transid + "\n  accountnumber=" + accountnumber + "\n amount=" + amount
			+ "\n amountrecieved=" + amountrecieved + "\n transtype=" + transtype + "\n Transdate=" + Transdate + "]";
}

public long getTransid() {
	return Transid;
}

public void setTransid(long transid) {
	Transid = transid;
}

public long getAccountnumber() {
	return accountnumber;
}

public void setAccountnumber(long accountnumber) {
	this.accountnumber = accountnumber;
}

public long getAmount() {
	return amount;
}

public void setAmount(long amount) {
	this.amount = amount;
}

public long getAmountrecieved() {
	return amountrecieved;
}

public void setAmountrecieved(long amountrecieved) {
	this.amountrecieved = amountrecieved;
}

public String getTranstype() {
	return transtype;
}

public void setTranstype(String transtype) {
	this.transtype = transtype;
}

public String getTransdate() {
	return Transdate;
}

public void setTransdate(String transdate) {
	Transdate = transdate;
}


}
