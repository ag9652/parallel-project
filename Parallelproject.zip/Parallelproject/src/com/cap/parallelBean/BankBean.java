package com.cap.parallelBean;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BankBean implements Serializable{
private long accountno;
private String name,DOB,password;
private int balance;
private long phoneno;


public BankBean (long accountno, String name, String dOB, String password, int balance, long phoneno) {
	super();
	this.accountno = accountno;
	this.name = name;
	this.DOB = dOB;
	this.password = password;
	this.balance = balance;
	this.phoneno = phoneno;
	
}
@Override
public String toString() {
	return "*********Account Details********* \n accountno = " + accountno + "\n name=" + name + "\n DOB=" + DOB + "\n password=" + password
			+ "\n balance=" + balance + "\n phoneno=" + phoneno + "";
}




public long getAccountno() {
	return accountno;
}


public void setAccountno(long accountno) {
	this.accountno = accountno;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getDOB() {
	return DOB;
}


public void setDOB(String dOB) {
	DOB = dOB;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}



public int getBalance() {
	return balance;
}


public void setBalance(int balance) {
	this.balance = balance;
}


public long getPhoneno() {
	return phoneno;
}


public void setPhoneno(long phoneno) {
	this.phoneno = phoneno;
}



}
