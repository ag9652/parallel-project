package com.cap.parallelDAO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.cap.parallelBean.BankBean;
import com.cap.parallelBean.TransBean;



public class BankDAO implements BankDAOI 
{
	int sb1,q1,q2;
	int dep2;
	long i=456783;
	HashMap<Long, BankBean> hm=new HashMap<Long, BankBean>();
	HashMap<TransBean,Long> hmq=new HashMap<TransBean,Long>();
	ArrayList<TransBean> al;
	
		
		
	
	public boolean createAccount(BankBean bean)
	{
		//hm=new HashMap();
		hm.put(bean.getAccountno(),bean);
		if(hm.containsKey(bean.getAccountno()))
		{
			return true;
		}
		return false;
	}
	
	public int showbalance(long accountno1,String password1)
	{
		BankBean bean1=(BankBean) hm.get(accountno1);
		if(bean1==null)
		{
			throw new AccountNotFoundException("invalid Account number");
		}
		else
		{
			sb1=bean1.getBalance();
			return sb1;
		}
		/*System.out.println(bean1);
		//System.out.println(bean1.getPassword());
		if((bean1.getPassword()).equals(password1))
		{
			
			sb1=bean1.getBalance();
		}	return sb1;*/
		
		
	}
	public long deposit1(long accountno2,String password2,int dep1)
	{
		if(hm.containsKey(accountno2))
		{
			BankBean bean1=(BankBean) hm.get(accountno2);
			if(bean1.getPassword().equals(password2))
			{
				dep2=bean1.getBalance()+dep1;
				bean1.setBalance(dep2);;
				
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
			    Date date = new Date();  
			    
				
				TransBean tb=new TransBean();
				tb.setAccountnumber(accountno2);
				tb.setAmount(dep1);
				tb.setTransid(++i);
				tb.setTranstype("deposit");
				tb.setTransdate(formatter.format(date));
				hmq.put(tb, accountno2);
				System.out.println(al);
			}
					
		}
		return dep2;
	}
	public int withdraw(long accountno21, String password21, int witdr) {
		// TODO Auto-generated method stub
		if(hm.containsKey(accountno21))
		{
			BankBean bean1=(BankBean) hm.get(accountno21);
			if(bean1.getPassword().equals(password21))
			{
				dep2=bean1.getBalance()-witdr;
				bean1.setBalance(dep2);;
				
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
			    Date date = new Date();  
			    
				
				TransBean tb=new TransBean();
				tb.setAccountnumber(accountno21);
				tb.setAmount(witdr);
				tb.setTransid(++i);
				tb.setTranstype("withdraw");
				tb.setTransdate(formatter.format(date));
				hmq.put(tb, accountno21);
				
			}
					
		}
		return dep2;
		
	}
	
	public int fund1(long accountno31, long accountno32, String password31, int k1) {
		// TODO Auto-generated method stub
		BankBean be1= (BankBean) hm.get(accountno31);
		BankBean be12=(BankBean) hm.get(accountno32);
		if(be1==null)
		{
			throw new AccountNotFoundException("invalid account 1");
		}
		else if(!be1.getPassword().equals(password31))
		{
			throw new PasswordNotFoundException("invalid password of account 1");
		}
		else if(be12==null)
		{
			throw new AccountNotFoundException("invalid account 2");
		}
		q1=be1.getBalance()-k1;
		q2=be12.getBalance()+k1;
		be1.setBalance(q1);
		be12.setBalance(q2);
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date();  
	    
		
		TransBean tb=new TransBean();
		tb.setAccountnumber(accountno31);
		tb.setAmount(k1);
		tb.setTransid(++i);
		tb.setAmountrecieved(accountno32);
		tb.setTranstype("fund");
		tb.setTransdate(formatter.format(date));
		hmq.put(tb, accountno31);
		return q1;
	}
	public boolean validation(long accountno1,String password1)
	{
		if(hm.containsKey(accountno1))
		{
			BankBean bean4 = (BankBean) hm.get(accountno1);
			if(bean4.getPassword().equals(password1))
			{
				return true;
			}
		}
		return false;
		
	}
	public boolean validation1(long accountno31,long accountno32,String password31)
	{
		if(hm.containsKey(accountno31)&& hm.containsKey(accountno32))
		{
			BankBean bean4 = (BankBean) hm.get(accountno31);
			if(bean4.getPassword().equals(password31))
			{
				return true;
			}
		}
		return false;
		
	}

	public List<TransBean> transa() {
		// TODO Auto-generated method stub
		al=new ArrayList<TransBean>(hmq.keySet());
		
		return al;
	}
	
}
