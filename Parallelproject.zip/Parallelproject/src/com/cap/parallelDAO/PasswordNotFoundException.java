package com.cap.parallelDAO;

@SuppressWarnings("serial")
public class PasswordNotFoundException extends RuntimeException
{
	public PasswordNotFoundException(String s)
	{
			super(s);
	}
		
}
